RASTA PYRAMID FACTORY v0.1.5 TEST - new TPKX stage

What changed: only the MBTiles -> TPKX step. It now writes exactly the same
TPKX structure as mb2tpkx 1.1 (the converter whose maps you fly in ArcGIS Earth).
Checked against your demo_lon_41.tpkx: all 24 bundles byte-for-byte identical.
Everything else in Rasta is v0.1.3, unchanged.

TEST 1 - the converter on its own (2 minutes):
  1. Extract All. Double-click Convert_MBTiles_to_TPKX_v0.3.0.bat
  2. Pick demo_lon_41.mbtiles, save as demo_lon_41_v030.tpkx
  3. Drag it onto ArcGIS Earth: London should look exactly like your demo_lon_41.tpkx.

TEST 2 - a full Rasta build:
  1. Open the "Rasta Pyramid Factory" folder, run "Run Rasta Self Test.bat" - expect SELF TEST PASSED.
  2. Start Rasta Pyramid Factory, build any picture with TPKX (or Both) ticked.
  3. Open the TPKX in ArcGIS Earth. Flat pictures park off Jacksonville at 30 N, 80 W.

OPTIONAL - Field Maps: if you still have the Field Maps / Designer card workflow,
try one v0.3.0 TPKX there. That is the test the old converter failed in August.
