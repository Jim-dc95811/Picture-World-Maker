RASTA PYRAMID FACTORY v0.2.0 TEST - PHOTO MODE (no QGIS for pictures)

What changed: flat pictures (photos, panoramas) are tiled directly - no QGIS.
Same tiles and same spot on the ocean as v0.1.6, so your gates still line up.
Measured here on Kings_reach_panorama_1.jpg: about 48 seconds (v0.1.6: 8 min 46 s),
TPKX 442 MB (v0.1.6: 1.77 GB).

TEST 1 - first start:
  Double-click "Start Rasta Pyramid Factory.bat". The first time it installs the
  Pillow helper (one time only), then the window opens titled v0.2.0 TEST.

TEST 2 - Kings Reach again:
  1. CHOOSE IMAGE: C:\Dump\Kings_reach_panorama_1.jpg
  2. The green recipe line should say: PHOTO MODE - no QGIS needed
  3. TPKX, Name: Kings_reach_panorama_1_photo, BUILD. Note the time.
  4. Drag the new TPKX onto ArcGIS Earth (untick the old one) and fly it.
     Look at: sharpness at about Z18, the picture edges (no black border),
     and compare with the old 1.7 GB one.

TEST 3 - self-test: "Run Rasta Self Test.bat" -> SELF TEST PASSED.

Settings (System Files\Rasta_Config.ini, [PHOTO]):
  engine = qgis  -> back to the v0.1.6 QGIS route for photos
  tiles = png    -> all-PNG tiles (bigger files)
Real map rasters (GeoTIFFs with coordinates) still use QGIS automatically.
