@echo off
cd /d "%~dp0"
title MBTiles to TPKX v0.3.0 (Rasta v0.1.6 TEST)
echo Pick an .mbtiles file, then where to save the .tpkx
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 "Rasta Pyramid Factory\System Files\MBTiles_to_TPKX_v0_3_0.py"
) else (
    python "Rasta Pyramid Factory\System Files\MBTiles_to_TPKX_v0_3_0.py"
)
pause
