RASTA PYRAMID FACTORY v0.1.6 TEST

v0.1.5: the TPKX step writes exactly what mb2tpkx 1.1 writes (your London TPKX: byte-identical).
v0.1.6: five fixes from a full code review (details: releases/v0.1.6_TEST_RELEASE_NOTES.md on GitHub).

TEST 1 - self-test: open "Rasta Pyramid Factory", run "Run Rasta Self Test.bat" -> SELF TEST PASSED.

TEST 2 - a full build: Start Rasta Pyramid Factory, choose a picture, TPKX ticked, BUILD.
   Drag the TPKX onto ArcGIS Earth (flat pictures park off Jacksonville, 30 N 80 W).

TEST 3 - the fixes (each takes a minute):
   a. Start a build, press CANCEL while QGIS is working -> a "Build cancelled" box appears
      within a second or two (before: no box, and it could take a long time).
   b. Start a build, close the window with the X -> "Stopping the build and cleaning up",
      then it closes. Task Manager should show no qgis / python-qgis left running.
   c. Set Max zoom to 24 with TPKX ticked, press BUILD -> refused at once with a clear message.

Converter on its own: Convert_MBTiles_to_TPKX_v0.3.0.bat, pick demo_lon_41.mbtiles.
Optional: one TPKX through Field Maps settles the August question.
